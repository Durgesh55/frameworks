package com.automation.steps;

import com.automation.utils.ConfigReader;
import com.automation.utils.RestAssureUtils;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.junit.Assert;

import java.util.Optional;

public class ResponseSteps {
    @Then("verify status code is {int}")
    public void verify_status_code_is(int statusCode) {
     Assert.assertEquals(statusCode, RestAssureUtils.getStatusCode());
    }

    @And("verify booking id is not empty")
    public void verifyBookingIdIsNotEmpty() {
    }

    @And("user stores created booking id into {string}")
    public void userStoresCreatedBookingIdInto(String key) {

    }

    @And("store token value to {string}")
    public void storeTokenValueTo(String arg0) {
    }
}
