package com.automation.steps;

import com.automation.utils.ConfigReader;
import com.automation.utils.RestAssureUtils;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.io.FileNotFoundException;

public class RequestSteps {
    @Given("user wants to call {string} end point")
    public void user_wants_to_call_end_point(String endPoint) {
        if(endPoint.contains("@id")){
            String bookingId= ConfigReader.getConfigValue("booking.id");
            RestAssureUtils.setEndPoint(endPoint+bookingId);

        }
        else {
            RestAssureUtils.setEndPoint(endPoint);
        }

    }

    @Given("set header {string} to {string}")
    public void set_header_content_type_to_application_json(String key, String value) {
        RestAssureUtils.setHeader(key,value);

    }

    @Given("set request body from the file {string}")
    public void set_request_body_from_the_file(String fileName) {
        RestAssureUtils.setBody(fileName);

    }

    @When("user performs post call")
    public void user_performs_post_call() {
        RestAssureUtils.post();
    }


    @When("user performs get call")
    public void userPerformsGetCall() {
        RestAssureUtils.get();
    }

    @And("user performs put call")
    public void userPerformsPutCall() {
        RestAssureUtils.put();
    }
}
