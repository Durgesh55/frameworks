package com.automation.pages;

import com.microsoft.playwright.Locator;
import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;


public class SearchPage extends BasePage{
    Locator pageNum;
    Locator nextButton;
    Locator previousButton;
    Locator radio;
    public SearchPage(){
        pageNum= page.locator("li.pagination-paginationMeta");
        nextButton=page.locator("li.pagination-next");
        previousButton=page.locator("li.pagination-prev");

    }
    int firstPageNumber;
    public void clickOnNExtButton() {
        String s=pageNum.textContent().substring(5,6).trim();
        firstPageNumber=Integer.parseInt(s);
        System.out.println(firstPageNumber);
        nextButton.click();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
    int secondPageNumber;
    public void isNextPageDisplayed() {
        String s=pageNum.textContent().substring(5,6).trim();
        secondPageNumber=Integer.parseInt(s);
        System.out.println(secondPageNumber);
        assertThat(pageNum).containsText("Page "+(firstPageNumber+1));
    }

    public void clickOnPreviousButton() {
        previousButton.click();
    }

    public void isPreviousPageDisplayed() {
        assertThat(pageNum).containsText("Page "+(secondPageNumber-1));
    }
    String filter;
    public void doFilter(String name) {
            try {
                radio = page.locator((String.format("//input[contains(@value,'%s.')]", name)));
            }catch (Exception e){
                radio = page.locator((String.format("//input[contains(@value,'%s,')]", name)));
            }
            radio.click();
            filter = name;
        }


    public boolean checkFilterGender() {
        try {
            Thread.sleep(3000);
        } catch (Exception ignored) {
        }
        return radio.isChecked();
    }
}
