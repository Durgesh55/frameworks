package com.automation.pages;

import com.automation.utils.ConfigReader;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

public class HomePage extends BasePage{
    Locator searchBar;
    Locator searchButton;
    Locator searchItem;

   public HomePage(){
       searchBar=page.getByPlaceholder("Search");
       searchButton=page.locator("//a[contains(@class,'submit')]");
       searchItem=page.locator("//span[@class='breadcrumbs-crumb']");
    }

    public void openWebsite() {
        page.navigate(ConfigReader.getConfigValue("application.url"));
    }

    public void searchForItem(String item) {
       searchBar.fill(item);
       searchButton.click();

    }

    public Locator itemsDisplayed() {
       return searchItem;
    }
    public Locator isSearchBarDisplayed(){
       return searchBar;
    }

    public void clickOnNavigation(String nav) {
        Locator navigation=page.locator(String.format("//a[@data-group='%s']",nav));
        navigation.click();
    }

    public boolean isNavigatedPageDisplayed(String nav) {
        String currentUrl= page.url();
        System.out.println(currentUrl);
        return currentUrl.contains(nav);
    }
}
