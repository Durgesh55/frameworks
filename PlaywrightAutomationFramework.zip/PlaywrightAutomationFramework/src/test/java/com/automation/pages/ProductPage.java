package com.automation.pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

import java.util.List;

public class ProductPage extends BasePage {
    Locator firstProductRating;
    List<Locator> searchResults;
    Locator ratingOnPdpPage;

    public ProductPage() {
        firstProductRating = page.locator("(//div[@class='product-ratingsContainer']/span[1])[1]");
        searchResults=page.locator("//li[@class='product-base']").all();
        ratingOnPdpPage=page.locator("//div[@class='index-overallRating']/div[1]");

    }
    String rating1;
    public void getRating() {
        rating1 = firstProductRating.textContent();
        System.out.println(rating1);
    }
    Page newPage;
    public void clickOnFirst(){
            searchResults.get(0).click();
    }
    String rating2;
    public boolean verifyRating() {
        newPage = page.waitForPopup(() -> {
            rating2=ratingOnPdpPage.textContent();
            System.out.println(rating2);

        });
        return rating1.equals(rating2);
        }
}
