package com.automation.steps;

import com.automation.pages.HomePage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

public class NavigationSteps {
    HomePage homePage=new HomePage();

    @When("user clicks on a {string} link")
    public void userClicksOnALink(String nav) {
        homePage.clickOnNavigation(nav);
    }

    @Then("verify page is navigated to respective {string} link")
    public void verifyPageIsNavigatedToRespectiveLink(String nav) {
        Assert.assertTrue(homePage.isNavigatedPageDisplayed(nav));
    }
}
