package com.automation.steps;

import com.automation.pages.HomePage;
import com.automation.pages.SearchPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

public class SearchSteps {
    HomePage homePage=new HomePage();
    SearchPage searchPage=new SearchPage();
    @Given("user opens website")
    public void user_opens_website() {
        homePage.openWebsite();
    }

    @When("user search for {string}")
    public void user_search_for(String item) {
        homePage.searchForItem(item);
       
    }


    @Then("verify the searched product is displayed")
    public void verifyTheSearchedProductIsDisplayed() {
        assertThat(homePage.itemsDisplayed()).isVisible();

    }

    @Then("verify home page is displayed")
    public void verifyHomePageIsDisplayed() {
        assertThat(homePage.isSearchBarDisplayed()).isVisible();
    }


    @When("user clicks on next button")
    public void userClicksOnNextButton() {
        searchPage.clickOnNExtButton();
    }

    @Then("verify next page is displayed")
    public void verifyNextPageIsDisplayed() {
       searchPage.isNextPageDisplayed();
    }

    @When("user clicks previous button")
    public void userClicksPreviousButton() {
        searchPage.clickOnPreviousButton();
    }

    @Then("verify previous page is displayed")
    public void verifyPreviousPageIsDisplayed() {
        searchPage.isPreviousPageDisplayed();
    }
    @When("user wants to filter by {string}")
    public void userWantsToFilterBy(String name) {
        searchPage.doFilter(name);
    }
    @Then("verify gender filter is applied")
    public void verifyGenderFilterIsApplied() {
        Assert.assertTrue(searchPage.checkFilterGender());
    }

}
