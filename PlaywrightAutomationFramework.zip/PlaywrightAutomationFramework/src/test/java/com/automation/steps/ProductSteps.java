package com.automation.steps;

import com.automation.pages.ProductPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

public class ProductSteps {
    ProductPage productPage=new ProductPage();
    @When("user get the product rating")
    public void userGetTheProductRating() {
        productPage.getRating();
    }

    @And("user clicks on the first product")
    public void userClicksOnTheFirstProduct() {
        productPage.clickOnFirst();
        
    }

    @Then("verify the product rating on product description page")
    public void verifyTheProductRatingOnProductDescriptionPage() {
        Assert.assertTrue(productPage.verifyRating());

    }
}
