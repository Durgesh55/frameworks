function fun(){
        var config={
            host : "https://dummy.restapiexample.com/api/v1"
        }
        return config;
}