package automation.pages;

import automation.utils.ConfigReader;
import automation.utils.DriverManager;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import java.util.Random;

public class LoginPage extends BasePage {
    @FindBy(id = "j_username")
    WebElement userName;

    @FindBy(id = "j_password")
    WebElement password;

    @FindBy(xpath = "//button[@name='Submit']")
    WebElement signInButton;

    @FindBy(xpath = "//*[@id=\"tasks\"]/div[1]/span/a")
    WebElement newItem;

    @FindBy(id = "name")
    WebElement itemName;

    @FindBy(xpath = "//li[@class='hudson_model_FreeStyleProject']")
    WebElement freeStyleProject;

    @FindBy(id = "ok-button")
    WebElement okButton;

    @FindBy(id = "radio-block-2")
    WebElement gitRadioButton;

    @FindBy(xpath = "//input[@name='_.url']")
    WebElement gitUrl;

    @FindBy(xpath = "(//button[@class='jenkins-button hetero-list-add'])[5]")
    WebElement buildSteps;

    @FindBy(xpath = "//div[@class='jenkins-dropdown jenkins-dropdown--compact']/button[5]")
    WebElement invokeMaven;


    @FindBy(xpath = "(//button[@class='jenkins-button hetero-list-add'])[6]")
    WebElement postBuildAction;

    @FindBy(xpath = "//div[@class='jenkins-dropdown jenkins-dropdown--compact']/button[4]")
    WebElement cucumber;

    @FindBy(id = "textarea._.targets")
    WebElement goals;

    @FindBy(xpath = "//button[@name='Submit']")
    WebElement save;

    @FindBy(xpath = "//span[text()='log out']")
    WebElement logoutButton;

    public LoginPage(){
        this.driver=DriverManager.getDriver();
    }

    public void openWebsite(){
        driver.get("http://localhost:8080/login?from=%2F");
    }
    public void enterLoginDetails(){
        userName.sendKeys(ConfigReader.getConfigValue("userName"));
        password.sendKeys(ConfigReader.getConfigValue("password"));
        signInButton.click();
    }

    public void clickNewItem(){
        newItem.click();
    }
    public void createNewItem(){
        Random random=new Random();
        String name="Project"+random.nextInt(100);
        itemName.sendKeys(name);
        freeStyleProject.click();
    }
    public void clickOkButton(){
        okButton.click();
    }
    public void newItemDetails(){
        JavascriptExecutor js=(JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();",gitRadioButton);
        gitUrl.sendKeys(ConfigReader.getConfigValue("url"));
        js.executeScript("arguments[0].click()",buildSteps);
        js.executeScript("arguments[0].click()",invokeMaven);
        goals.sendKeys("clean install");
        js.executeScript("arguments[0].click()",postBuildAction);
        js.executeScript("arguments[0].click()",cucumber);
    }
    public void clickSaveButton(){
        JavascriptExecutor js=(JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();",save);
    }
    public void clickLogoutButton(){
        logoutButton.click();
    }
    
}
