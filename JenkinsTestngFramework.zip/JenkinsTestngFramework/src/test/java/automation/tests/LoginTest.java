package automation.tests;

import automation.pages.LoginPage;
import org.testng.annotations.Test;

public class LoginTest extends BaseTest{
    @Test
    public void userLogin() {
        loginPage.openWebsite();
        loginPage.enterLoginDetails();
        loginPage.clickNewItem();
        loginPage.createNewItem();
        loginPage.clickOkButton();
        loginPage.newItemDetails();
        loginPage.clickSaveButton();
        loginPage.clickLogoutButton();
    }

}
