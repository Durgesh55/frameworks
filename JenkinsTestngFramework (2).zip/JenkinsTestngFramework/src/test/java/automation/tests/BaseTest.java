package automation.tests;

import automation.pages.LoginPage;
import automation.utils.ConfigReader;
import automation.utils.DriverManager;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class BaseTest {
    LoginPage loginPage;
    @BeforeMethod
    public void setUp(){
        ConfigReader.initConfig();
        DriverManager.createDriver();
        loginPage=new LoginPage();
    }
    @AfterMethod
    public void cleanUp(){
        //DriverManager.getDriver().quit();
    }
}
