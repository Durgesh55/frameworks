package automation.tests;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class ExtentReportListner implements ITestListener {
    private static ExtentReports extentReports;
    private static ExtentTest test;

    public void onFinish(ITestContext context){
        extentReports.flush();
    }
    public void onStart(ITestContext context){
        String reportPath=System.getProperty("user.dir")+"\\reports\\extentReport.html";
        ExtentSparkReporter reporter=new ExtentSparkReporter(reportPath);
        extentReports=new ExtentReports();
        extentReports.attachReporter(reporter);
    }
    public void onTestStart(ITestResult result){
        test=extentReports.createTest(result.getMethod().getMethodName());

    }
    public void onTestSuccess(ITestResult result){
        test.pass("Test Passed");
    }
    public void onTestFailure(ITestResult result){
        test.fail("Test Failedd");
    }
}
