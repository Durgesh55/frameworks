package automation.pages;

import automation.utils.DriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import java.time.Duration;

public class BasePage {
    WebDriver driver;

    public BasePage() {
        this.driver = DriverManager.getDriver();
        PageFactory.initElements(this.driver, this);
    }


    public boolean isDisplay(WebElement element) {
        try {

            return element.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
}
