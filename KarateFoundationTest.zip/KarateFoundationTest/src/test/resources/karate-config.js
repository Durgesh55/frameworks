function fun(){
        var config={
            host : "https://freefakeapi.io/api"

        }
        return config;
}