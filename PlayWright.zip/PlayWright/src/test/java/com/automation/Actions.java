package com.automation;

import com.microsoft.playwright.*;

import java.util.List;

public class Actions {
    public static void main(String[] args) {
        Playwright playwright = Playwright.create();
        Browser browser = playwright.chromium().launch(
                new BrowserType.LaunchOptions().setHeadless(false)
        );
        Page page = browser.newPage();
        page.navigate("https://www.globalsqa.com/demo-site/draganddrop/");
        FrameLocator frame=page.frameLocator("(//iframe[contains(@class,'demo-frame ')])[1]");
        List<Locator> images = frame.locator("//ul[@id='gallery']/li").all();
        Locator trash=frame.locator("#trash");
        for (Locator i:images){
            i.dragTo(trash);
        }
    }
}
