package com.automation;

import com.microsoft.playwright.*;

public class Expedia {
    public static void main(String[] args) {
        Playwright playwright=Playwright.create();
        Browser browser=playwright.firefox().launch(
                new BrowserType.LaunchOptions().setHeadless(false)
        );
        Page page=browser.newPage();
        page.navigate("https://www.expedia.com");

        page.locator("//span[text()='Flights']").click();
        page.locator("//button[@aria-label='Leaving from']").click();
        page.locator("input#origin_select").fill("Hyderabad");
        page.locator("//button[@aria-label='Hyderabad (HYD - Rajiv Gandhi Intl.) India']").click();

        page.locator("//button[@aria-label='Going to']").click();
        page.locator("input#destination_select").fill("Delhi");
        page.locator("//button[@aria-label='Delhi (DEL - Indira Gandhi Intl.) India']").click();

        page.locator("//button[@name='EGDSDateRange-date-selector-trigger']").click();
        page.locator("//*[@id=\"app-layer-datepicker-start\"]/section/div[2]/div[2]/div[1]/div[2]/table/tbody/tr[3]/td[1]").click();
        page.locator("//button[@aria-label='Sep 21, 2024. -. Price not available']").click();

    }
}
