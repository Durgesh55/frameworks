package com.automation;

import com.microsoft.playwright.*;
import com.microsoft.playwright.options.SelectOption;

public class Ebay {
    public static void main(String[] args) {
        Playwright playwright=Playwright.create();
        Browser browser=playwright.chromium().launch(
                new BrowserType.LaunchOptions().setHeadless(false)
        );
        Page page=browser.newPage();
        page.navigate("https://ebay.com");
        Locator advanced=page.locator("a#gh-as-a");
        advanced.click();
        Locator dropdown= page.locator("(//select[@name='_sacat'])[2]");
        dropdown.click();
        dropdown.selectOption(new SelectOption().setValue("267"));
        page.locator("(//input[@class='checkbox__control'])[1]").click();
        Locator minPrice=page.locator("//input[@aria-label='Enter minimum price range value, $']");
        minPrice.scrollIntoViewIfNeeded();
        minPrice.fill("0");
        page.locator("//input[@aria-label='Enter maximum price range value, $']").fill("100");
        Locator checkBox=page.locator("(//fieldset[@class='adv-fieldset__condition']//label[@class='field__label--end'])[1]");
        checkBox.scrollIntoViewIfNeeded();
        checkBox.click();
        Locator searchButton=page.locator("(//button[text()='Search'])[2]");
        searchButton.scrollIntoViewIfNeeded();
        searchButton.click();
//        context switching
        Page newPage=page.waitForPopup(() -> {
            page.locator("//a[@class='s-item__link'][not(@tabindex)]").first().click();
        });
        newPage.close();
        playwright.close();
    }
}
