package com.automation;

import com.microsoft.playwright.*;

import java.util.List;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;


public class DemoClass {
    public static void main(String[] args) {
        Playwright playwright=Playwright.create();
        Browser browser=playwright.chromium().launch(
                new BrowserType.LaunchOptions().setHeadless(false)
        );
        Page page=browser.newPage();
        page.navigate("https://www.saucedemo.com");
        Locator userNameInput=page.locator("#user-name");
        Locator password=page.locator("#password");
        Locator loginButton=page.locator("#login-button");
        userNameInput.fill("standard_user");
        password.fill("secret_sauce");
        loginButton.click();
        assertThat(page.locator("span.title")).hasText("Products");
        List<Locator> list= page.locator("div.inventory_item_name ").all();
        System.out.println(list.size());
        list.get(0).click();
        page.locator("button#add-to-cart").click();
        page.locator("a.shopping_cart_link").click();
        page.locator("button#checkout").click();
        page.locator("input#first-name").fill("aa");
        page.locator("input#last-name").fill("bb");
        page.locator("input#postal-code").fill("123");
        page.locator("input#continue").click();
        page.locator("button#finish").click();
        System.out.println(page.locator("span.title").textContent());
        System.out.println(page.locator("h2.complete-header").textContent());
        assertThat(page.locator("h2.complete-header")).hasText("Thank you for your order!");
        playwright.close();
        System.out.println("Execution complete");
    }
}
