package com.automation;

import com.microsoft.playwright.*;
import com.microsoft.playwright.options.MouseButton;

import java.nio.file.Path;
import java.nio.file.Paths;

public class Herokuapp {
    public static void main(String[] args) throws InterruptedException {
        Playwright playwright = Playwright.create();
        Browser browser = playwright.chromium().launch(
                new BrowserType.LaunchOptions().setHeadless(false)
        );
        Page page = browser.newPage();
        page.navigate("https://the-internet.herokuapp.com");

        //text input
        page.getByText("Inputs").click();
        page.locator("//input[@type='number']").fill("123");

        //checkboxes
        page.navigate("https://the-internet.herokuapp.com");
        page.getByText("Checkboxes").click();
        page.locator("//input[@type='checkbox'][1]").check();

        //select options
        page.navigate("https://the-internet.herokuapp.com");
        page.getByText("Dropdown").click();
        Locator select=page.locator("select#dropdown");
        select.selectOption("1");
        Thread.sleep(2000);

        //mouse click
        page.navigate("https://the-internet.herokuapp.com");
        page.getByText("Hovers").click();
        page.locator("(//img[@alt='User Avatar'])[2]").hover();
        Thread.sleep(2000);

        //keys and shortcuts
        page.navigate("https://the-internet.herokuapp.com");
        page.getByText("Key Presses").click();
        page.locator("input#target").fill("abcd");
        page.locator("input#target").press("Control+A");
        Thread.sleep(2000);
        page.locator("input#target").press("Delete");
        Thread.sleep(2000);

        //drag and drop
        page.navigate("https://the-internet.herokuapp.com");
        page.getByText("Drag and Drop").click();
        page.locator("div#column-a").dragTo(page.locator("div#column-b"));
        Thread.sleep(2000);

        //upload file

        page.navigate("https://the-internet.herokuapp.com/upload");
        Locator fileInput =page.locator("#file-upload");
        fileInput.setInputFiles(Paths.get("src/test/resources/abc.txt"));
        Thread.sleep(2000);

        // Scroll the footer into view, forcing an "infinite list" to load more content
        page.navigate("https://the-internet.herokuapp.com");
        page.getByText("Elemental Selenium").scrollIntoViewIfNeeded();

    }

}
